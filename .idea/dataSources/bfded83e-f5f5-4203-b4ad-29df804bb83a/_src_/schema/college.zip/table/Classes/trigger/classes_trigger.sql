CREATE TRIGGER classes_trigger
AFTER INSERT ON Classes
FOR EACH ROW
  INSERT INTO updateTimeTableClasses VALUES ("Classes Table",DEFAULT );
